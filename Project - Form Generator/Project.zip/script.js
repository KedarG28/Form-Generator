function add1() {

  let a = document.querySelector("#elements");
  let outerbox = document.querySelector(".generateFormWithTitles");
  let box = document.createElement("div");
  let part1 = document.createElement("div");
  let part2 = document.createElement("div");
  let inp1 = document.createElement("input");
  let inp2 = document.createElement("input");
  let btn1 = document.createElement("button");

  part1.className = "part1";
  box.className = "box";
  part2.className = "part2";
  inp1.id = "lab1";
  inp1.type = a.textContent;
  inp2.type = a.value;
  inp2.placeholder = a.value;
  btn1.textContent = "Add Name";


  btn1.addEventListener("click", () => {
    let nameAdd = document.createElement("p");
    nameAdd.textContent = inp1.value;
    inp1.style.display = "none";
    btn1.style.display = "none";
    part1.appendChild(nameAdd);
  });

  let btn2 = document.createElement("button");
  btn2.addEventListener("click", () => {
    box.remove();
  });

    btn2.className = "cancel";
    btn2.textContent = "X";

  

  part1.appendChild(inp1);
  part1.appendChild(btn1);
  part2.appendChild(inp2);
  part2.appendChild(btn2);
  box.appendChild(part1);
  box.appendChild(part2);
  outerbox.appendChild(box);

  if (a.value == "radio") {
    function fun1() {
      inp2.remove();

      let part3 = document.createElement("div");
      let inp4 = document.createElement("input");
      let inp3 = document.createElement("input");
      let btn3 = document.createElement("button");

      part3.className = "part3";
      inp4.type = "radio";
      inp3.type = "text";
      inp3.className = "inp3";
      inp3.placeholder = "options";
      btn3.id = "addoption";
      btn3.textContent = "Add";

      part3.appendChild(inp4);
      part3.appendChild(inp3);
      part3.appendChild(btn3);
      part2.appendChild(part3);

      btn3.addEventListener("click", () => {
        if (!inp3.value.trim()) return;

        let nameAdd = document.createElement("p");
        nameAdd.textContent = inp3.value;
        btn3.remove();
        inp3.remove();
        part3.appendChild(nameAdd);
        fun1();
      });
    }
    fun1();
  }

  else if (a.value == "select") {
    function fun2() {
      inp2.remove();

      let part4 = document.createElement("div");
      let select = document.createElement("select");
      let inpField = document.createElement("input");
      let addButton = document.createElement("button");


      part4.className = "part4";
      select.id = "select";
      inpField.placeholder = "Option";
      inpField.id = "inpField";
      addButton.id = 'addButton';
      addButton.textContent = "+";


      addButton.addEventListener("click", ()=>{
        let o = document.createElement("option");
        o.textContent = inpField.value;
        select.appendChild(o);
        inpField.value = '';
        
      });

      part4.appendChild(select);
      part4.appendChild(inpField);
      part4.appendChild(addButton);
      part2.appendChild(part4);
      
    }
    fun2();
  }

  else if(a.value == 'checkbox'){
    function fun3(){
    inp2.remove();
    let part5 = document.createElement('div');
    let multicheck = document.createElement('input');
    let inp5 = document.createElement("input");
    let btn5 = document.createElement("button");


    part5.className = "part5";
    multicheck.type = 'checkbox';
    multicheck.className = 'multicheck';
    inp5.id = 'inp5';
    inp5.type = 'text';
    inp5.placeholder = 'Option'
    btn5.id = 'btn5';
    btn5.textContent = '+';


    btn5.addEventListener('click',()=>{
      let addName = document.createElement('p');
      addName.textContent = inp5.value;
      inp5.remove();
      btn5.remove();
      part5.appendChild(addName);
      fun3();
    })


    part5.appendChild(multicheck);
    part5.appendChild(inp5);
    part5.appendChild(btn5);
    part2.appendChild(part5);

    }
    fun3()
  }
  else if(a.value == 'submit'){
    inp1.remove();
    btn1.remove();
    inp2.remove();

    let btn6 = document.createElement("button");
    let inp6 = document.createElement("input");

    part6 = document.createElement('div');
    part6.className = 'part6';
    btn6.id = 'btn6'
    btn6.textContent = '+';
    inp6.placeholder = 'Button Name';

    btn6.addEventListener("click", () => {
      let nameAdd = document.createElement("button");
      nameAdd.id = 'buttonName'
      nameAdd.textContent = inp6.value;
      inp6.style.display = "none";
      btn6.style.display = "none";
      part6.appendChild(nameAdd);
    });

    
    part6.appendChild(inp6);
    part6.appendChild(btn6);
    part2.appendChild(part6);
  }

}

function generateform(){

  let finalForm = document.querySelector('.finalForm');
  let finalBox = document.querySelectorAll('.box');
  let delbtns = document.getElementsByClassName('cancel');
  let part3 = document.querySelectorAll('.part3');
  let inp3 = document.querySelectorAll('.inp3');

  // Remove any radio option blocks (part3) that still have an empty input (no option added)
  inp3.forEach((input) => {
    if (!input.value.trim()) {
      const parent = input.closest('.part3');
      if (parent) parent.remove();
    }
  });

  Array.from(delbtns).forEach((button) => {
    button.remove();
  });
  
  finalForm.append(...finalBox);
}
